package main;
import telaLogin.telaLogin;
import pessoas.Cliente;
import pessoas.Endereco;
import pessoas.Funcionario;
import pessoas.Pessoa;

public class App{

public static void main(String[] args) {
    telaLogin tela = new telaLogin();
    tela.exibirFrame();
 }
}
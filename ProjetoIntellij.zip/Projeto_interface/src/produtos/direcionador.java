package produtos;
import java.util.ArrayList;
import componentes.componente;

class direcionador extends produto{

    ArrayList<componente> directioner = new ArrayList<>();

    void preencher(componente barraPinos, componente capacitor100nF, componente regulador,
    componente ESP8266, componente LedAzul, componente placaPCI, componente resistor150R,
    componente resistor100R, componente resistor330R, componente chaveHH, componente parafusoM28,
    componente parafusoM325, componente adesivo){
        directioner.add(barraPinos);
        directioner.add(capacitor100nF);
        directioner.add(regulador);
        directioner.add(ESP8266);
        directioner.add(LedAzul);
        directioner.add(placaPCI);
        directioner.add(resistor150R);
        directioner.add(resistor100R);
        directioner.add(resistor330R);
        directioner.add(chaveHH);
        directioner.add(parafusoM28);
        directioner.add(parafusoM325);
        directioner.add(adesivo);
    }
    
}
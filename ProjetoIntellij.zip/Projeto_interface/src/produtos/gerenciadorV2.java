package produtos;
import java.util.ArrayList;
import componentes.componente;

class direcionador extends produto{

    ArrayList<componente> managerV2 = new ArrayList<>();

    void preencher(componente capacitor470nF, componente amplificador,
    componente barraPinos, componente PIC18F2550, componente placaPCI, componente usb,
    componente resistor10KR, componente resistor330R, componente regulador, componente parafusoM28,
    componente parafusoM325, componente gabinete, componente raioBicicleta, componente adesivo,
    componente pushButton, componente resistor1KR){
        managerV2.add(barraPinos);
        managerV2.add(usb);
        managerV2.add(capacitor470nF);
        managerV2.add(amplificador);
        managerV2.add(regulador);
        managerV2.add(PIC18F2550);
        managerV2.add(placaPCI);
        managerV2.add(pushButton);
        managerV2.add(resistor1KR);
        managerV2.add(resistor10KR);
        managerV2.add(resistor330R);
        managerV2.add(parafusoM325);
        managerV2.add(parafusoM28);
        managerV2.add(raioBicicleta);
        managerV2.add(gabinete);
        managerV2.add(adesivo);
    }
    
}
package produtos;
import java.util.ArrayList;
import componentes.componente;

class direcionador extends produto{

    ArrayList<componente> managerV1 = new ArrayList<>();

    void preencher(componente capacitor100nF, componente amplificador,
    componente ESP8266, componente LedAzul, componente placaPCI, componente resistor150R,
    componente resistor10KR, componente resistor330R, componente chaveHH, componente parafusoM28,
    componente parafusoM325, componente gabinete, componente raioBicicleta, componente adesivo){
        managerV1.add(capacitor100nF);
        managerV1.add(amplificador);
        managerV1.add(ESP8266);
        managerV1.add(LedAzul);
        managerV1.add(placaPCI);
        managerV1.add(resistor150R);
        managerV1.add(resistor10KR);
        managerV1.add(resistor330R);
        managerV1.add(chaveHH);
        managerV1.add(parafusoM28);
        managerV1.add(parafusoM325);
        managerV1.add(gabinete);
        managerV1.add(raioBicicleta);
        managerV1.add(adesivo);
    }
    
}
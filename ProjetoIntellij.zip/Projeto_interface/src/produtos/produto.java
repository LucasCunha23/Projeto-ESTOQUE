package produtos; 
import java.util.ArrayList;
import componentes.componente;
import main.App;

public class produto extends App{
    String nome;
    float precoTotal;
    String descricao;
    public void setNome(String nome) {
        this.nome = nome;
    }
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    public void setPrecoTotal(float precoTotal) {
        this.precoTotal = precoTotal;
    }
    
}
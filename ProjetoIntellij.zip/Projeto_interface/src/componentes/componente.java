package componentes;

public class componente{
    String nome;
    int quantidade;
    double preco;
    String descricao;
    
    public static void componentes(){
        componente barraPinos = new componente();
        barraPinos.setNome("Barra de Pinos");
        barraPinos.setPreco(2.40);
        barraPinos.setDescricao("necessária para a conexão do microcontrolador");

        componente capacitor100nF = new componente();
        capacitor100nF.setNome("capacitor100nF");
        capacitor100nF.setPreco(0.30);
        capacitor100nF.setDescricao("capacitor de 100nF");

        componente reguladorTensao = new componente();
        reguladorTensao.setNome("reguladorTensao");
        reguladorTensao.setPreco(1.90);
        reguladorTensao.setDescricao("regulador de Tensao");

        componente ESP8266 = new componente();
        ESP8266.setNome("ESP3266");
        ESP8266.setPreco(35);
        ESP8266.setDescricao("microcontrolador ESP3266");

        componente LedAzul = new componente();
        LedAzul.setNome("LedAzul");
        LedAzul.setPreco(0.20);
        LedAzul.setDescricao("LED SMD 0603 AZUL");

        componente placaPCI = new componente();
        placaPCI.setNome("placaPCI");
        placaPCI.setPreco(3.50);
        placaPCI.setDescricao("placa de circuito impresso");

        componente resistor150R = new componente();
        resistor150R.setNome("Resistor150R");
        resistor150R.setPreco(0.05);
        resistor150R.setDescricao("Resistor SMD 150 Ohm");

        componente resistor100R = new componente();
        resistor100R.setNome("resistor100R");
        resistor100R.setPreco(0.05);
        resistor100R.setDescricao("Resistor SMD 100 Ohm");

        componente resistor330R = new componente();
        resistor330R.setNome("resistor330R");
        resistor330R.setPreco(0.05);
        resistor330R.setDescricao("Resistor SMD 330 Ohm");

        componente chaveHH = new componente();
        chaveHH.setNome("chaveHH");
        chaveHH.setPreco(0.60);
        chaveHH.setDescricao("Chave HH");

        componente parafusoM28 = new componente();
        parafusoM28.setNome("Parafuso M2x8");
        parafusoM28.setPreco(0.20);
        parafusoM28.setDescricao("Parafuso cabeca cilindrica M2x8");

        componente parafusoM325 = new componente();
        parafusoM325.setNome("Parafuso M3x25");
        parafusoM325.setPreco(0.25);
        parafusoM325.setDescricao("Parafuso escareado phillips M3x25");

        componente adesivo = new componente();
        adesivo.setNome("Adesivo");
        adesivo.setPreco(2.0);
        adesivo.setDescricao("Adesivo único modelo utilizado");

        componente capacitor470nF = new componente();
        capacitor470nF.setNome("capacitor470nF");
        capacitor470nF.setPreco(1.0);
        capacitor470nF.setDescricao("capacitor de 470nF");

        componente amplificador = new componente();
        amplificador.setNome("Amplificador");
        amplificador.setPreco(35.0);
        amplificador.setDescricao("Amplificador INA126p");

        componente pushButton = new componente();
        pushButton.setNome("Push Button");
        pushButton.setPreco(2.0);
        pushButton.setDescricao("Push button 6x6x9");

        componente resistor1KR = new componente();
        resistor1KR.setNome("Resistor1KR");
        resistor1KR.setPreco(0.05);
        resistor1KR.setDescricao("Resistor SMD 1KR Ohm");

        componente Resistor10KR = new componente();
        Resistor10KR.setNome("Resistor10KR");
        Resistor10KR.setPreco(0.05);
        Resistor10KR.setDescricao("Resistor SMD 10KR Ohm");

        componente raioBicicleta = new componente();
        raioBicicleta.setNome("raioBicicleta");
        raioBicicleta.setPreco(2.0);
        raioBicicleta.setDescricao("Raio de bicicleta");

        componente gabinete = new componente();
        gabinete.setNome("Gabinete");
        gabinete.setPreco(50.0);
        gabinete.setDescricao("Gabinete");

        componente usb = new componente();
        usb.setNome("Usb");
        usb.setPreco(11.0);
        usb.setDescricao("Conector USB");

        componente PIC18F2550 = new componente();
        PIC18F2550.setNome("PIC18F2550");
        PIC18F2550.setPreco(160.0);
        PIC18F2550.setDescricao("Microcontrolador PIC18F2550");

        
        
    }
    

    public double getPreco() {
        return preco;
    }
    public String getNome() {
        return nome;
    }
    public String getDescricao() {
        return descricao;
    }
    public int getQuantidade() {
        return quantidade;
    }
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public void setPreco(double preco) {
        this.preco = preco;
    }
    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }
}